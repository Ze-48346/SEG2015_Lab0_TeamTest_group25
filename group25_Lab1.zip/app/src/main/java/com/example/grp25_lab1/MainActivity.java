package com.example.grp25_lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btn1;
    Button btn2;
    Button btn3;Button btn4;Button btn5;Button btn6;Button btn7;Button btn8;
    Button btn9;Button btn0;Button add;Button clear;Button sub;Button mul;Button div;
    Button dot;Button equ;
    EditText result;
    double num1=0;
    double num2=0;
    double Result=0;
    int op=0;
    String opd=" ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1=findViewById(R.id.btn_1);
        btn2=findViewById(R.id.btn_2);
        btn3=findViewById(R.id.btn_3);
        btn4=findViewById(R.id.btn_4);
        btn5=findViewById(R.id.btn_5);
        btn6=findViewById(R.id.btn_6);
        btn7=findViewById(R.id.btn_7);
        btn8=findViewById(R.id.btn_8);
        btn9=findViewById(R.id.btn_9);
        btn0=findViewById(R.id.btn_0);
        add = findViewById(R.id.btn_add);
        sub = findViewById(R.id.btn_minus);
        clear=findViewById(R.id.btn_clear);
        result=findViewById(R.id.display_result);
        dot=findViewById(R.id.btn_dot);
        equ=findViewById(R.id.btn_equal);
        mul=findViewById(R.id.btn_multiply);
        div=findViewById(R.id.btn_divide);
        btn1.setOnClickListener(new Click());
        btn2.setOnClickListener(new Click());
        btn3.setOnClickListener(new Click());
        btn4.setOnClickListener(new Click());
        btn5.setOnClickListener(new Click());
        btn6.setOnClickListener(new Click());
        btn7.setOnClickListener(new Click());
        btn8.setOnClickListener(new Click());
        btn9.setOnClickListener(new Click());
        btn0.setOnClickListener(new Click());
        add.setOnClickListener(new Click());
        sub.setOnClickListener(new Click());
        mul.setOnClickListener(new Click());
        div.setOnClickListener(new Click());
        equ.setOnClickListener(new Click());
        dot.setOnClickListener(new Click());
        clear.setOnClickListener(new Click());
        result.setOnClickListener(new Click());



    }
    class Click implements View.OnClickListener{
        @SuppressLint({"NonConstantResourceId", "SetTextI18n"})
        public void onClick(View v){
            switch(v.getId()){
                case R.id.btn_0:
                    String str = result.getText().toString();
                    str+="0";
                    result.setText(str);
                    break;
                case R.id.btn_1:
                    String str1 = result.getText().toString();
                    str1+="1";
                    result.setText(str1);
                    break;
                case R.id.btn_2:
                    String str2 = result.getText().toString();
                    str2+="2";
                    result.setText(str2);
                    break;
                case R.id.btn_3:
                    String str3 = result.getText().toString();
                    str3+="3";
                    result.setText(str3);
                    break;
                case R.id.btn_4:
                    String str4 = result.getText().toString();
                    str4+="4";
                    result.setText(str4);
                    break;
                case R.id.btn_5:
                    String str5 = result.getText().toString();
                    str5+="5";
                    result.setText(str5);
                    break;
                case R.id.btn_6:
                    String str6 = result.getText().toString();
                    str6+="6";
                    result.setText(str6);
                    break;
                case R.id.btn_7:
                    String str7 = result.getText().toString();
                    str7+="7";
                    result.setText(str7);
                    break;
                case R.id.btn_8:
                    String str8 = result.getText().toString();
                    str8+="8";
                    result.setText(str8);
                    break;
                case R.id.btn_9:
                    String str9 = result.getText().toString();
                    str9+="9";
                    result.setText(str9);
                    break;
                case R.id.btn_dot:
                    String strDot=result.getText().toString();
                    strDot+=".";
                    result.setText(strDot);
                    break;
                case R.id.btn_add:
                    String strAdd = result.getText().toString();
                    num1 = Double.parseDouble(strAdd);
                    result.setText(null);
                    op=1;
                    opd="+";
                    break;
                case R.id.btn_minus:
                    String strMin = result.getText().toString();
                    num1= Double.parseDouble(strMin);
                    result.setText(null);
                    op=2;
                    opd="-";
                    break;
                case R.id.btn_multiply:
                    String strMul= result.getText().toString();
                    num1=Double.parseDouble(strMul);
                    result.setText(null);
                    op=3;
                    opd="x";
                    break;
                case R.id.btn_divide:
                    String strDiv=result.getText().toString();
                    num1= Double.parseDouble(strDiv);
                    result.setText(null);
                    op= 4;
                    opd="/";
                    break;
                case R.id.btn_clear:
                    result.setText(null);
                    break;
                case R.id.btn_equal:
                    String strEqu= result.getText().toString();
                    num2=Double.parseDouble(strEqu);
                    result.setText(null);
                    switch (op){
                        case 0:
                            Result= num2;
                            break;
                        case 1:
                            Result=num1+num2;
                            break;
                        case 2:
                            Result=num1-num2;
                            break;
                        case 3:
                            Result=num1*num2;
                            break;
                        case 4:
                            if(num2==0){
                                Result=0;
                            }else{
                                Result=num1/num2;
                            }
                            break;
                        default:
                            Result=0;
                            break;


                    }
                    result.setText(num1 +opd+num2+"="+Result);
                    break;
                default:
                    break;


            }
        }


    }
}