package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    Button btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btnA, btnS, btnM, btnD, btnE, btnP, btnC;
    TextView screen;
    double val1, val2, result;
    int r, val1dec, val2dec, decimal;
    boolean add, sub, mul, div, equ, poi, sign, second;
    String text1, text2, decfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn0 = (Button) findViewById(R.id.btn0);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);
        btn7 = (Button) findViewById(R.id.btn7);
        btn8 = (Button) findViewById(R.id.btn8);
        btn9 = (Button) findViewById(R.id.btn9);
        btnA = (Button) findViewById(R.id.btnA);
        btnS = (Button) findViewById(R.id.btnS);
        btnM = (Button) findViewById(R.id.btnM);
        btnD = (Button) findViewById(R.id.btnD);
        btnE = (Button) findViewById(R.id.btnE);
        btnP = (Button) findViewById(R.id.btnP);
        btnC = (Button) findViewById(R.id.btnC);
        screen = (TextView) findViewById(R.id.Screen1);

        add = false;
        sub = false;
        mul = false;
        div = false;
        equ = false;
        poi = false;
        val1 = 0;
        val2 = 0;
        result = 0;
        r = 0;
        text1 = "";
        text2 = "";
        sign = true;
        second = false;
        val1dec = 0;
        val2dec = 0;
        decimal = 0;
        decfo = "#.";

        btn0.setOnClickListener(v -> {
            if (!equ) {
                if (!second) {
                    screen.setText(screen.getText() + "0");
                    if(poi){
                        val1dec ++;
                        decimal = val1dec;
                    }
                } else {
                    screen.setText("");
                    screen.setText(screen.getText() + "0");
                    second = false;
                    if(poi){
                        val2dec ++;
                    }
                    if(val2dec>val1dec){
                        decimal = val2dec;
                    }
                }
            } else {
                btnC.callOnClick();
                screen.setText(screen.getText() + "0");
            }
        });
        btn1.setOnClickListener(v -> {
            if (!equ) {
                if (!second) {
                    screen.setText(screen.getText() + "1");
                    if(poi){
                        val1dec ++;
                        decimal = val1dec;
                    }
                } else {
                    screen.setText("");
                    screen.setText(screen.getText() + "1");
                    second = false;
                    if(poi){
                        val2dec ++;
                    }
                    if(val2dec>val1dec){
                        decimal = val2dec;
                    }
                }
            } else {
                btnC.callOnClick();
                screen.setText(screen.getText() + "1");
            }
        });
        btn2.setOnClickListener(v -> {
            if (!equ) {
                if (!second) {
                    screen.setText(screen.getText() + "2");
                    if(poi){
                        val1dec ++;
                        decimal = val1dec;
                    }
                } else {
                    screen.setText("");
                    screen.setText(screen.getText() + "2");
                    second = false;
                    if(poi){
                        val2dec ++;
                    }
                    if(val2dec>val1dec){
                        decimal = val2dec;
                    }
                }
            } else {
                btnC.callOnClick();
                screen.setText(screen.getText() + "2");
            }
        });
        btn3.setOnClickListener(v -> {
            if (!equ) {
                if (!second) {
                    screen.setText(screen.getText() + "3");
                    if(poi){
                        val1dec ++;
                        decimal = val1dec;
                    }
                } else {
                    screen.setText("");
                    screen.setText(screen.getText() + "3");
                    second = false;
                    if(poi){
                        val2dec ++;
                    }
                    if(val2dec>val1dec){
                        decimal = val2dec;
                    }
                }
            } else {
                btnC.callOnClick();
                screen.setText(screen.getText() + "3");
            }
        });
        btn4.setOnClickListener(v -> {
            if (!equ) {
                if (!second) {
                    screen.setText(screen.getText() + "4");
                    if(poi){
                        val1dec ++;
                        decimal = val1dec;
                    }
                } else {
                    screen.setText("");
                    screen.setText(screen.getText() + "4");
                    second = false;
                    if(poi){
                        val2dec ++;
                    }
                    if(val2dec>val1dec){
                        decimal = val2dec;
                    }
                }
            } else {
                btnC.callOnClick();
                screen.setText(screen.getText() + "4");
            }
        });
        btn5.setOnClickListener(v -> {
            if (!equ) {
                if (!second) {
                    screen.setText(screen.getText() + "5");
                    if(poi){
                        val1dec ++;
                        decimal = val1dec;
                    }
                } else {
                    screen.setText("");
                    screen.setText(screen.getText() + "5");
                    second = false;
                    if(poi){
                        val2dec ++;
                    }
                    if(val2dec>val1dec){
                        decimal = val2dec;
                    }
                }
            } else {
                btnC.callOnClick();
                screen.setText(screen.getText() + "5");
            }
        });
        btn6.setOnClickListener(v -> {
            if (!equ) {
                if (!second) {
                    screen.setText(screen.getText() + "6");
                    if(poi){
                        val1dec ++;
                        decimal = val1dec;
                    }
                } else {
                    screen.setText("");
                    screen.setText(screen.getText() + "6");
                    second = false;
                    if(poi){
                        val2dec ++;
                    }
                    if(val2dec>val1dec){
                        decimal = val2dec;
                    }
                }
            } else {
                btnC.callOnClick();
                screen.setText(screen.getText() + "6");
            }
        });
        btn7.setOnClickListener(v -> {
            if (!equ) {
                if (!second) {
                    screen.setText(screen.getText() + "7");
                    if(poi){
                        val1dec ++;
                        decimal = val1dec;
                    }
                } else {
                    screen.setText("");
                    screen.setText(screen.getText() + "7");
                    second = false;
                    if(poi){
                        val2dec ++;
                    }
                    if(val2dec>val1dec){
                        decimal = val2dec;
                    }
                }
            } else {
                btnC.callOnClick();
                screen.setText(screen.getText() + "7");
            }
        });
        btn8.setOnClickListener(v -> {
            if (!equ) {
                if (!second) {
                    screen.setText(screen.getText() + "8");
                    if(poi){
                        val1dec ++;
                        decimal = val1dec;
                    }
                } else {
                    screen.setText("");
                    screen.setText(screen.getText() + "8");
                    second = false;
                    if(poi){
                        val2dec ++;
                    }
                    if(val2dec>val1dec){
                        decimal = val2dec;
                    }
                }
            } else {
                btnC.callOnClick();
                screen.setText(screen.getText() + "8");
            }
        });
        btn9.setOnClickListener(v -> {
            if (!equ) {
                if (!second) {
                    screen.setText(screen.getText() + "9");
                    if(poi){
                        val1dec ++;
                        decimal = val1dec;
                    }
                } else {
                    screen.setText("");
                    screen.setText(screen.getText() + "9");
                    second = false;
                    if(poi){
                        val2dec ++;
                    }
                    if(val2dec>val1dec){
                        decimal = val2dec;
                    }
                }
            } else {
                btnC.callOnClick();
                screen.setText(screen.getText() + "9");
            }
        });
        btnA.setOnClickListener(v -> {
            if (!add  && !sub && !mul && !div) {
                if (screen.getText() != "") {
                    add = true;
                    sign = true;
                    second = true;
                    poi = false;
                    text1 = screen.getText().toString();
                    if (!sign) {
                        val1 = 0 - Float.parseFloat(text1);
                    } else {
                        val1 = Float.parseFloat(text1);
                    }
                }
            }
        });
        btnS.setOnClickListener(v -> {
            if (!add && !sub && !mul && !div) {
                if (screen.getText() != "") {
                    sub = true;
                    sign = true;
                    second = true;
                    poi = false;
                    text1 = screen.getText().toString();
                    if (!sign) {
                        val1 = 0 - Float.parseFloat(text1);
                    } else {
                        val1 = Float.parseFloat(text1);
                    }
                } else {
                    screen.setText(screen.getText() + "-");
                    sign = false;
                }
            } else if (equ) {
                btnC.callOnClick();
                screen.setText(screen.getText() + "-");
                sign = false;
            }
        });
        btnM.setOnClickListener(v -> {
            if (!add  && !sub && !mul && !div) {
                if (screen.getText() != "") {
                    mul = true;
                    sign = true;
                    second = true;
                    poi = false;
                    text1 = screen.getText().toString();
                    if (!sign) {
                        val1 = 0 - Float.parseFloat(text1);
                    } else {
                        val1 = Float.parseFloat(text1);
                    }
                }
            }
        });
        btnD.setOnClickListener(v -> {
            if (!add  && !sub && !mul && !div) {
                if (screen.getText() != "") {
                    div = true;
                    sign = true;
                    second = true;
                    poi = false;
                    text1 = screen.getText().toString();
                    if (!sign) {
                        val1 = 0 - Float.parseFloat(text1);
                    } else {
                        val1 = Float.parseFloat(text1);
                    }
                }
            }
        });
        btnE.setOnClickListener(v -> {
            if (!equ) {
                if (screen.getText() != "") {
                    equ = true;
                    second = true;
                    text1 = screen.getText().toString();
                    if (add || sub || mul || div) {
                        if (!sign) {
                            val2 = 0 - Float.parseFloat(text1);
                        } else {
                            val2 = Float.parseFloat(text1);
                        }
                        if (add) {
                            result = val1 + val2;
                            if (result == Math.floor(result)) {
                                r = (int)result;
                                text2 = Integer.toString(r);
                                screen.setText(text2);
                            } else {
                                for(int i=0;i<decimal;i++){
                                    decfo = decfo+"#";
                                }
                                DecimalFormat df = new DecimalFormat(decfo);
                                text2 = df.format(result);
                                screen.setText(text2);
                            }
                        }
                        if (sub) {
                            result = val1 - val2;
                            if (result == Math.floor(result)) {
                                r = (int)result;
                                text2 = Integer.toString(r);
                                screen.setText(text2);
                            } else {
                                for(int i=0;i<decimal;i++){
                                    decfo = decfo+"#";
                                }
                                DecimalFormat df = new DecimalFormat(decfo);
                                text2 = df.format(result);
                                screen.setText(text2);
                            }
                        }
                        if (mul) {
                            result = val1 * val2;
                            if (result == Math.floor(result)) {
                                r = (int)result;
                                text2 = Integer.toString(r);
                                screen.setText(text2);
                            } else {
                                for(int i=0;i<decimal;i++){
                                    decfo = decfo+"#";
                                }
                                DecimalFormat df = new DecimalFormat(decfo);
                                text2 = df.format(result);
                                screen.setText(text2);
                            }
                        }
                        if (div) {
                            if (val2 != 0) {
                                result = val1 / val2;
                                if (result == Math.floor(result)) {
                                    r = (int)result;
                                    text2 = Integer.toString(r);
                                    screen.setText(text2);
                                } else {
                                    for(int i=0;i<decimal;i++){
                                        decfo = decfo+"#";
                                    }
                                    DecimalFormat df = new DecimalFormat(decfo);
                                    text2 = df.format(result);
                                    screen.setText(text2);
                                }
                            }
                        }
                    }
                }
            }
        });
        btnP.setOnClickListener(v -> {
            if (!poi) {
                if (screen.getText() != "") {
                    screen.setText(screen.getText() + ".");
                    poi = true;
                }
            }
        });
        btnC.setOnClickListener(v -> {
            screen.setText("");
            add = false;
            sub = false;
            mul = false;
            div = false;
            equ = false;
            poi = false;
            val1 = 0;
            val2 = 0;
            result = 0;
            r = 0;
            text1 = "";
            text2 = "";
            sign = true;
            second = false;
            val1dec = 0;
            val2dec = 0;
        });
    }
}