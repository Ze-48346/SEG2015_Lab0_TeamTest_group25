package com.example.simplecalculator;

import androidx.appcompat.app.AppCompatActivity;
import java.math.BigDecimal;

import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btnPlus,btnMinus,btnMultiply,btnDivide,btnClear,btnDot,btnEqual;
    TextView display;
//    double val1,val2;
    String str1,str2;
    BigDecimal decimalVal1, decimalVal2;
    boolean plus = false;
    boolean minus = false;
    boolean negative = false;
    boolean multiply = false;
    boolean divide = false;
    boolean equalResult = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.displayScreen);
        btn0 = findViewById(R.id.btn0);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);

        btnPlus = findViewById(R.id.btnPlus);
        btnMinus = findViewById(R.id.btnMinus);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnDivide = findViewById(R.id.btnDivide);

        btnClear = findViewById(R.id.btnClear);
        btnDot = findViewById(R.id.btnDot);
        btnEqual = findViewById(R.id.btnEqual);

        btn0.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (equalResult == true){
                    display.setText("");
                    equalResult = false;
                }
                display.setText(display.getText() + "0");
            }
        });

        btn1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (equalResult == true){
                    display.setText("");
                    equalResult = false;
                }
                display.setText(display.getText() + "1");
            }
        });

        btn2.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (equalResult == true){
                    display.setText("");
                    equalResult = false;
                }
                display.setText(display.getText() + "2");
            }
        });

        btn3.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (equalResult == true){
                    display.setText("");
                    equalResult = false;
                }
                display.setText(display.getText() + "3");
            }
        });

        btn4.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (equalResult == true){
                    display.setText("");
                    equalResult = false;
                }
                display.setText(display.getText() + "4");
            }
        });

        btn5.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (equalResult == true){
                    display.setText("");
                    equalResult = false;
                }
                display.setText(display.getText() + "5");
            }
        });

        btn6.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (equalResult == true){
                    display.setText("");
                    equalResult = false;
                }
                display.setText(display.getText() + "6");
            }
        });

        btn7.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (equalResult == true){
                    display.setText("");
                    equalResult = false;
                }
                display.setText(display.getText() + "7");
            }
        });

        btn8.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (equalResult == true){
                    display.setText("");
                    equalResult = false;
                }
                display.setText(display.getText() + "8");
            }
        });

        btn9.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (equalResult == true){
                    display.setText("");
                    equalResult = false;
                }
                display.setText(display.getText() + "9");
            }
        });

        btnClear.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                display.setText("");
                plus = false;
                minus = false;
                multiply = false;
                divide = false;
                str1 = "";
                str2 = "";
//                val1 = 0;
//                val2 = 0;
            }
        });

        btnDot.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v){
                display.setText(display.getText() + ".");
            }
        });

        btnPlus.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v){
                try{
                    if ( display.getText().equals("") ){
                        display.setText("");
                    } else {
                        if(negative == true){
//                            val1 = - Float.parseFloat(display.getText()+"");
                            str1 = "-" + display.getText();
                            negative = false;
                        } else {
                            str1 = display.getText()+"";
//                            val1 = Float.parseFloat(display.getText()+"");
                        }

                        display.setText("");
                        plus = true;
                        minus = false;
                        multiply = false;
                        divide = false;
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }

            }
        });

        btnMinus.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v){
                try{
                    if ( display.getText().equals("") ){
                        display.setText("");
                        negative = true;

                    } else {
                        if(negative == true){
//                            val1 = - Float.parseFloat(display.getText()+"");
                            str1 = "-" + display.getText();
                            negative = false;
                        } else {
//                            val1 = Float.parseFloat(display.getText()+"");
                            str1 = "" + display.getText();
                        }
                        display.setText("");
                        minus = true;
                        plus = false;
                        multiply = false;
                        divide = false;
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }

            }
        });

        btnMultiply.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v){
                try{
                    if ( display.getText().equals("") ){
                        display.setText("");
                    } else {
                        if(negative == true){
//                            val1 = - Float.parseFloat(display.getText()+"");
                            str1 = "-" + display.getText();
                            negative = false;
                        } else {
//                            val1 = Float.parseFloat(display.getText()+"");
                            str1 = "" + display.getText();

                        }
                        display.setText("");
                        multiply = true;
                        minus = false;
                        plus = false;
                        divide = false;
                    }
                }catch(Exception e){
                  e.printStackTrace();
                }

            }
        });

        btnDivide.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v){
                try{
                    if ( display.getText().equals("") ){
                        display.setText("");
                    } else {
                        if(negative == true){
//                            val1 = - Float.parseFloat(display.getText()+"");
                            str1 = "-" + display.getText();
                            negative = false;
                        } else {
//                            val1 = Float.parseFloat(display.getText()+"");
                            str1 = "" + display.getText();
                        }
                        display.setText("");
                        divide = true;
                        minus = false;
                        plus = false;
                        multiply = false;
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });

        btnEqual.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v){
                try{
                    if ( display.getText().equals("") ){
                        display.setText("");

                    } else if (plus == true){
//                        val2 = Float.parseFloat(display.getText()+"");
                        str2 = ""+ display.getText();
                        decimalVal1 = new BigDecimal(str1);
                        decimalVal2 = new BigDecimal(str2);

                        System.out.println(decimalVal1);
//                        System.out.println(val1);
                        System.out.println(decimalVal2);
//                        System.out.println(val2);
//                        System.out.println(decimalVal1.add(decimalVal2));

//                        val2 = 0;
//                        val1 = Float.parseFloat(display.getText()+ "");
                        display.setText(decimalVal1.add(decimalVal2)+"");
                        str2 = "";
                        str1 = display.getText()+"";
                        plus = false;
                        minus = false;
                        multiply = false;
                        divide = false;
                        equalResult = true;

                    } else if (minus == true){
//                        val2 = Float.parseFloat(display.getText()+"");
//                        display.setText(val1 - val2 + "");
//                        val2 = 0;
//                        val1 = Float.parseFloat(display.getText()+ "");
                        str2 = ""+ display.getText();
                        decimalVal1 = new BigDecimal(str1);
                        decimalVal2 = new BigDecimal(str2);
                        display.setText(decimalVal1.subtract(decimalVal2)+"");
                        plus = false;
                        minus = false;
                        multiply = false;
                        divide = false;
                        equalResult = true;

                    } else if (multiply == true){
//                        val2 = Float.parseFloat(display.getText()+"");
//                        display.setText(val1 * val2 + "");
//                        val2 = 0;
//                        val1 = Float.parseFloat(display.getText()+ "");
                        str2 = ""+ display.getText();
                        decimalVal1 = new BigDecimal(str1);
                        decimalVal2 = new BigDecimal(str2);
                        display.setText(decimalVal1.multiply(decimalVal2)+"");
                        plus = false;
                        minus = false;
                        multiply = false;
                        divide = false;
                        equalResult = true;

                    } else if (divide == true){
                        if (display.getText().equals("0")){
                            display.setText("Invalid divisor");
//                            val1 = 0;
//                            val2 = 0;
                            str1 = "";
                            str2 = "";
                            plus = false;
                            minus = false;
                            multiply = false;
                            divide = false;
                        } else{
                            str2 = ""+ display.getText();
                            decimalVal1 = new BigDecimal(str1);
                            decimalVal2 = new BigDecimal(str2);
                            try{
                                display.setText(decimalVal1.divide(decimalVal2)+"");
                            }catch (Exception e){
                                display.setText(decimalVal1.divide(decimalVal2,10,BigDecimal.ROUND_HALF_UP)+"");
                            }

                            plus = false;
                            minus = false;
                            multiply = false;
                            divide = false;
                            equalResult = true;
                        }

                    }

                }catch(Exception e){
                    e.printStackTrace();
                }


            }
        });


    }

}